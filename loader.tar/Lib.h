/* Lib.h */
#ifndef LIB_H
#define LIB_H

void foobar(int i);

#endif 
