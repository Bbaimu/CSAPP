int test_static = 100;

int swap(int *a, int *b)
{
	test_static += 10000;
	*a ^= *b ^= *a ^= *b;
	return 0;
}
