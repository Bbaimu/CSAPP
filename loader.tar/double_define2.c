#include<stdio.h>
#include"double_define.h"


double weak;

void printB()
{
	printf("in the printB the value of n : %d\n", n);
	printf("weak is a double %lf", weak);
}
