#include"double_define.h"
extern weak ;


int main(void)
{
	weak = 0x123f;
	printA();
	printB();

	return 0;
}
