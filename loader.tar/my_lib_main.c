int static_main = 10;

extern int  static_lib;
void test_function(void);

void define_in_main(void)
{
	static_main++;
	static_lib++;
}

int main(void)
{

	test_function();

	return 0;
}
