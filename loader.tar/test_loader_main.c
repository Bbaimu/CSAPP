int main_static = 10;
extern int test_static ;

int swap(int *a, int *b);


int main()
{
	int main_local = 1;
	swap(&main_static, &test_static);
	swap(&main_local,  &test_static);

	return 0;
}
