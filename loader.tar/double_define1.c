#include<stdio.h>
#include"double_define.h"

int weak;

void printA()
{
	printf("in the printA  the value of n : %d\n", n);
	printf("weak is a interger %d", weak);
}
