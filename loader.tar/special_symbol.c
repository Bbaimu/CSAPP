/*
 * special_symbol.c 
 *
 */

#include<stdio.h>

extern char __executable_start[];
extern char etext[], _etext[], __etext[];
extern char edata[], _edata[];
extern char end[], _end[];

int main()
{
	printf("Executable start %X \n", (unsigned int)__executable_start);
	printf("Text end %X  %X %X \n", (unsigned int)etext, (unsigned int)_etext, (unsigned int)__etext );
	printf("data end %X  %X", (unsigned int)edata, (unsigned int)_edata);
	printf("Executable end %X  %X", (unsigned int)end, (unsigned int)_end);

	return 0;
}
