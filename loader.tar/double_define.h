#ifndef DOUBLE_DEFINE
#define DOUBLE_DEFINE
#include<stdio.h>


int n;

#endif
