int static_lib = 10;

extern int static_main;
void define_in_main(void);

void define_in_lib(void)
{
	static_lib++;
	static_main++;
}

void test_function(void)
{
	define_in_main();
	define_in_lib();
}
