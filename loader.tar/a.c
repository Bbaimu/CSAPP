extern int shared;

double wang;
int main()
{
	int a = 100;
	swap(&a, &shared);
}
