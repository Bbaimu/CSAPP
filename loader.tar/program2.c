#include"Lib.h"

int main()
{
	foobar(2);
	return 0;
}
